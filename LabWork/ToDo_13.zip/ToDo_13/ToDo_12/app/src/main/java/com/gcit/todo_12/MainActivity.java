package com.gcit.todo_12;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.google.android.material.snackbar.Snackbar;

public class MainActivity extends AppCompatActivity {
    String list;
    public static final String LOG = MainActivity.class.getName();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void Donut(View view) {
        String donut = "You ordered a donut";
        list = donut;
        Toast.makeText(this,"You ordered donut",Toast.LENGTH_SHORT).show();
    }

    public void ice_cream(View view) {
        String ice_cream = "You ordered a donut";
       list = ice_cream;
        Toast.makeText(this,"You ordered Ice cream sandwiche",Toast.LENGTH_SHORT).show();
    }

    public void froyo(View view) {
        String froyo = "You ordered a donut";
        list = froyo;
        Toast.makeText(this,"You ordered froyo",Toast.LENGTH_SHORT).show();
    }


    public void post(View view) {
        Intent intent = new Intent(getApplicationContext(),Order.class);
        intent.putExtra("list",list);
        startActivity(intent);
    }
}